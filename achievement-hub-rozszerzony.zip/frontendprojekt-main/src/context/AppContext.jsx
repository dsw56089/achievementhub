import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { games as initialGames } from '../data/mockData'

const AppContext = createContext(null)
const STORAGE_KEY = 'achievement-hub-state-v2'

export function AppProvider({ children }) {
  const [games] = useState(initialGames)
  const [importedAchievements, setImportedAchievements] = useState(() => {
    try { return JSON.parse(localStorage.getItem('achievement-hub-imported-v1') || '[]') } catch { return [] }
  })
  const [completed, setCompleted] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem('achievement-hub-state-v1') || '{"completed":[],"downloaded":[],"pinned":[]}')
      return { ...saved, pinned: saved.pinned || [], downloaded: saved.downloaded || saved.pinned || [] }
    } catch {
      return { completed: [], downloaded: [], pinned: [] }
    }
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(completed))
  }, [completed])

  useEffect(() => {
    localStorage.setItem('achievement-hub-imported-v1', JSON.stringify(importedAchievements))
  }, [importedAchievements])

  const toggleCompleted = (achievementId) => {
    setCompleted((current) => ({
      ...current,
      completed: current.completed.includes(achievementId)
        ? current.completed.filter((id) => id !== achievementId)
        : [...current.completed, achievementId],
    }))
  }

  const togglePinned = (achievementId) => {
    setCompleted((current) => ({
      ...current,
      pinned: (current.pinned || []).includes(achievementId)
        ? current.pinned.filter((id) => id !== achievementId)
        : [...(current.pinned || []), achievementId],
    }))
  }

  const downloadAchievement = (achievement, game) => {
    setCompleted((current) => {
      if ((current.downloaded || []).some((item) => item.id === achievement.id)) return current
      return { ...current, downloaded: [...(current.downloaded || []), { ...achievement, gameId: game.id, gameTitle: game.title }] }
    })
  }

  const removeDownloaded = (achievementId) => {
    setCompleted((current) => ({ ...current, downloaded: (current.downloaded || []).filter((item) => item.id !== achievementId) }))
  }

  const importCollection = (items) => {
    setCompleted((current) => {
      const merged = [...(current.downloaded || [])]
      items.forEach((item) => {
        const exists = merged.some((entry) => entry.id === item.id)
        if (!exists) merged.push(item)
      })
      return { ...current, downloaded: merged }
    })
    const known = new Set(games.flatMap((game) => game.achievements.map((a) => a.id)))
    setImportedAchievements((current) => {
      const merged = [...current]
      items.filter((item) => !known.has(item.id)).forEach((item) => {
        if (!merged.some((entry) => entry.id === item.id)) merged.push(item)
      })
      return merged
    })
  }

  const value = useMemo(() => ({
    games,
    completed: completed.completed,
    pinned: completed.pinned || [],
    downloaded: completed.downloaded || [],
    importedAchievements,
    downloadAchievement,
    removeDownloaded,
    importCollection,
    toggleCompleted,
    togglePinned,
    getProgress: (game) => {
      const ids = game.achievements.map((item) => item.id)
      const count = ids.filter((id) => completed.completed.includes(id)).length
      return { count, total: ids.length, percent: ids.length ? Math.round((count / ids.length) * 100) : 0 }
    },
  }), [games, completed, importedAchievements])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) throw new Error('useApp musi być użyty wewnątrz AppProvider')
  return context
}
