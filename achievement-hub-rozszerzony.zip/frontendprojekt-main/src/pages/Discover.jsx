import { useMemo, useState } from 'react'
import { Compass, Download, Search, SlidersHorizontal, Sparkles, Check } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Discover() {
  const { games, importedAchievements, downloaded, downloadAchievement } = useApp()
  const [query, setQuery] = useState('')
  const [gameFilter, setGameFilter] = useState('Wszystkie gry')
  const [rarityFilter, setRarityFilter] = useState('Wszystkie')
  const [sort, setSort] = useState('points')
  const catalog = games.flatMap((game) => game.achievements.filter((a) => a.custom).map((achievement) => ({ ...achievement, game })))
  const imported = importedAchievements.map((achievement) => ({
    ...achievement,
    game: games.find((game) => game.id === achievement.gameId) || { id: achievement.gameId, title: achievement.gameTitle || 'Importowane osiągnięcie' },
  }))
  const items = useMemo(() => {
    const all = [...catalog, ...imported].filter((item, index, list) => list.findIndex((x) => x.id === item.id) === index)
    const filtered = all.filter((item) => {
      const text = `${item.title} ${item.description} ${item.author || ''} ${item.game.title}`.toLowerCase()
      return text.includes(query.toLowerCase()) &&
        (gameFilter === 'Wszystkie gry' || item.game.id === gameFilter) &&
        (rarityFilter === 'Wszystkie' || item.rarity === rarityFilter)
    })
    return filtered.sort((a, b) => sort === 'name' ? a.title.localeCompare(b.title, 'pl') : sort === 'points' ? (b.points || 0) - (a.points || 0) : (b.points || 0) - (a.points || 0))
  }, [catalog, imported, query, gameFilter, rarityFilter, sort])
  const isDownloaded = (id) => downloaded.some((item) => item.id === id)

  return <div className="content-wrap discover-page">
    <div className="eyebrow purple"><Compass size={13}/> SPOŁECZNOŚĆ</div>
    <h1>Odkrywaj <span>nowe wyzwania.</span></h1>
    <p className="lead">Przeglądaj osiągnięcia innych graczy, filtruj je i dodawaj ciekawe wyzwania do swojej kolekcji.</p>
    <section className="discover-controls">
      <label className="search-box"><Search size={17}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Szukaj osiągnięcia, gry, autora..."/></label>
      <label className="filter-box"><SlidersHorizontal size={16}/><select value={gameFilter} onChange={(e) => setGameFilter(e.target.value)}><option>Wszystkie gry</option>{games.map((game) => <option key={game.id} value={game.id}>{game.title}</option>)}</select></label>
      <label className="filter-box"><select value={rarityFilter} onChange={(e) => setRarityFilter(e.target.value)}><option>Wszystkie</option>{['Pospolite','Rzadkie','Epickie','Legendarne'].map((r) => <option key={r}>{r}</option>)}</select></label>
      <label className="filter-box"><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="points">Sortuj: najwięcej XP</option><option value="name">Nazwa A–Z</option></select></label>
    </section>
    <div className="discover-results"><span>{items.length} osiągnięć</span><span>{downloaded.length} w Twojej kolekcji</span></div>
    {items.length ? <div className="discover-grid">{items.map((item) => <article className="discover-card" key={item.id}>
      <div className="discover-card-top"><Sparkles size={16}/><span>{item.game.title}</span></div>
      <h3>{item.title}</h3><p>{item.description}</p>
      <div className="discover-card-foot"><span>{item.rarity || 'Społecznościowe'} · {item.points || 0} XP</span><span>Autor: {item.author || 'Import'}</span></div>
      <button className={`collection-action ${isDownloaded(item.id) ? 'is-added' : ''}`} disabled={isDownloaded(item.id)} onClick={() => downloadAchievement(item, item.game)}>
        {isDownloaded(item.id) ? <><Check size={15}/> W kolekcji</> : <><Download size={15}/> Pobierz do kolekcji</>}
      </button>
    </article>)}</div> : <div className="empty-state">Nie znaleziono osiągnięć dla wybranych filtrów.</div>}
  </div>
}
