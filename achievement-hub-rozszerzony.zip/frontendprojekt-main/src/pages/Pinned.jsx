import { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Download, FileDown, FileUp, Trash2, Trophy } from 'lucide-react'
import { useApp } from '../context/AppContext'
import AchievementRow from '../components/AchievementRow'

export default function Pinned() {
  const { downloaded, removeDownloaded, completed, toggleCompleted, pinned, togglePinned, importCollection } = useApp()
  const fileRef = useRef(null)
  const [message, setMessage] = useState('')
  const exportJson = () => {
    const payload = { format: 'achievement-hub-collection', version: 1, exportedAt: new Date().toISOString(), achievements: downloaded }
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = 'achievement-hub-kolekcja.json'
    anchor.click()
    URL.revokeObjectURL(url)
    setMessage(`Wyeksportowano ${downloaded.length} osiągnięć.`)
  }
  const importJson = async (event) => {
    const file = event.target.files?.[0]
    if (!file) return
    try {
      const data = JSON.parse(await file.text())
      if (data.format !== 'achievement-hub-collection' || !Array.isArray(data.achievements)) throw new Error('Nieprawidłowy format pliku.')
      const valid = data.achievements.filter((a) => a && typeof a.id === 'string' && typeof a.title === 'string' && typeof a.gameId === 'string')
      if (!valid.length && data.achievements.length) throw new Error('Plik nie zawiera poprawnych osiągnięć.')
      importCollection(valid)
      setMessage(`Zaimportowano ${valid.length} osiągnięć. Duplikaty zostały pominięte.`)
    } catch (error) {
      setMessage(error instanceof SyntaxError ? 'Plik nie zawiera poprawnego JSON.' : error.message || 'Nie udało się zaimportować pliku.')
    }
    event.target.value = ''
  }

  return <div className="content-wrap pinned-page">
    <div className="eyebrow purple"><Trophy size={13}/> TWOJA KOLEKCJA</div>
    <h1>Moje <span>osiągnięcia.</span></h1>
    <p className="lead">Osiągnięcia pobrane ze społeczności. Twoja kolekcja jest zapisywana lokalnie w przeglądarce.</p>
    <div className="collection-toolbar">
      <div className="pinned-summary"><strong>{downloaded.length}</strong><span>zapisanych osiągnięć</span></div>
      <div className="collection-tools">
        <button className="outline-action" onClick={exportJson} disabled={!downloaded.length}><FileDown size={15}/> Eksportuj JSON</button>
        <button className="outline-action" onClick={() => fileRef.current?.click()}><FileUp size={15}/> Importuj JSON</button>
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={importJson}/>
      </div>
    </div>
    {message && <p className="import-message" role="status">{message}</p>}
    {downloaded.length ? <div className="achievement-list pinned-list">{downloaded.map((item) => <div className="pinned-item" key={item.id}>
      <div className="pinned-game">{item.gameTitle || item.gameId}</div>
      <AchievementRow achievement={{ ...item, rarity: item.rarity || 'Pospolite', points: item.points || 0, author: item.author || 'Import' }} isCompleted={completed.includes(item.id)} isPinned={pinned.includes(item.id)} onToggle={() => toggleCompleted(item.id)} onPin={() => togglePinned(item.id)}/>
      <button className="remove-collection" onClick={() => removeDownloaded(item.id)}><Trash2 size={14}/> Usuń z kolekcji</button>
    </div>)}</div> : <div className="empty-state pinned-empty">
      Nie masz jeszcze pobranych osiągnięć. Przejdź do odkrywania i dodaj wyzwania do swojej kolekcji.
      <p><Link to="/odkrywaj">Przeglądaj osiągnięcia społeczności</Link></p>
    </div>}
  </div>
}
